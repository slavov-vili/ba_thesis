﻿using System.Collections.Generic;
using System.Linq;

namespace Cabuu.Coach
{
    public class HistoryCollection : IJsonable
    {
        // DELEGATES
        /// <summary>
        /// This delegate describes a function that creates a new empty <see cref="EncounterHistory"/> for a given translation pair.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to build the empty encounter history for.</param>
        /// <returns>
        /// An empty encounter history.
        /// </returns>
        public delegate EncounterHistory EmptyHistoryBuilder(ParseObjectId pairId);

        /// <summary>
        /// This delegate describes a function that creates a new <see cref="EncounterHistory"/> using the given JSON data.
        /// Returns null if the JSON is improperly formatted for the encounter history type.
        /// </summary>
        /// <param name="obj">The JSON object to construct a encounter history from.</param>
        /// <returns>
        /// The encounter history represented by the given JSON object, or null if the JSON could not be parsed.
        /// </returns>
        public delegate EncounterHistory HistoryParser(JSONObject obj);

        // MEMBERS
        protected readonly Dictionary<ParseObjectId, EncounterHistory> pairs = new Dictionary<ParseObjectId, EncounterHistory>();
        protected readonly EmptyHistoryBuilder emptyBuilder;

        public int NumPairs
        {
            get { return pairs.Count; }
        }

        // CONSTRUCTORS
        protected HistoryCollection(EmptyHistoryBuilder emptyBuilder)
        {
            this.emptyBuilder = emptyBuilder;
        }


        // ====================
        // STATIC CONSTRUCTORS
        // ====================   

        /// <summary>
        /// Constructs a new, empty history collection object using the given encounter history construction method.
        /// </summary>
        /// <param name="emptyBuilder">Function used to create an empty encounter history.</param>
        /// <returns>
        /// The newly constructed <see cref="HistoryCollection"/> object.
        /// </returns>
        public static HistoryCollection Build(EmptyHistoryBuilder emptyBuilder)
        {
            return new HistoryCollection(emptyBuilder);
        }

        /// <summary>
        /// Constructs a new history collection object from the given history collection JSON object, using the given encounter history
        /// construction methods.  If an error occurs while parsing the JSON object, returns null.
        /// </summary>
        /// <param name="emptyBuilder">Function used to create an empty encounter history.</param>
        /// <param name="parser">Function used to parse an encounter history JSON object.</param>
        /// <param name="obj">The JSON object to parse.</param>
        /// <returns>
        /// The newly constructed <see cref="HistoryCollection"/> object, or null if the JSON object could not be parsed.
        /// </returns>
        public static HistoryCollection FromJSON(EmptyHistoryBuilder emptyBuilder, HistoryParser parser, JSONObject obj)
        {
            var hist = Build(emptyBuilder);
            foreach (EncounterHistory eh in obj.keys.Select(x => parser(obj.GetJSONObject(x))))
            {
                if (eh == null)
                    return null;
                hist.MergeHistory(eh);
            }

            return hist;
        }

        // ====================
        // METHODS (MAY BE OVERRIDEN BY SUBCLASSES)
        // ====================

        /// <summary>
        /// Retrieves the <see cref="EncounterHistory"/> for a particular translation pair.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to retrieve the history for.</param>
        /// <returns>
        /// The retrieved encounter history.
        /// </returns>
        public EncounterHistory GetHistory(ParseObjectId pairId)
        {
            return pairs[pairId] ?? emptyBuilder(pairId);
        }


        /// <summary>
        /// Adds the given translation pair to this history collection with an empty encounter history.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to instantiate an encounter history for.</param>
        public void AddTranslationPair(ParseObjectId pairId)
        {
            pairs[pairId] = emptyBuilder(pairId);
        }

        /// <summary>
        /// Removes the given translation pair from this history collection.  Use with caution.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to remove the history of.</param>
        public void RemoveTranslationPair(ParseObjectId pairId)
        {
            if (pairs.ContainsKey(pairId))
                pairs.Remove(pairId);
        }

        /// <summary>
        /// Removes the history for all translation pairs in this history collection, leaving this history collection
        /// entirely blank.  Use with caution.
        /// </summary>
        public void WipeCollection()
        {
            pairs.Clear();
        }

        /// <summary>
        /// Adds the given <see cref="LearnEncounter"/> to this history collection.
        /// </summary>
        /// <param name="encounter">The learning encounter to add.</param>
        public void AddEncounter(LearnEncounter encounter)
        {
            if (!pairs.ContainsKey(encounter.PairId))
                AddTranslationPair(encounter.PairId);
            pairs[encounter.PairId].AddEncounter(encounter);
        }


        /// <summary>
        /// Adds the given <see cref="LearnEncounter"/>s to this history collection.
        /// </summary>
        /// <param name="encounters">The learning encounters to add.</param>
        public void AddEncounters(IEnumerable<LearnEncounter> encounters)
        {
            foreach (LearnEncounter encounter in encounters)
                AddEncounter(encounter);
        }


        /// <summary>
        /// Adds the given <see cref="EncounterHistory"/> to this history collection, merging it with any existing encounter
        /// histories for the relevant translation pair.
        /// </summary>
        /// <param name="history">The encounter history to add.</param>
        public void MergeHistory(EncounterHistory history)
        {
            if (!pairs.ContainsKey(history.PairId))
                AddTranslationPair(history.PairId);
            pairs[history.PairId].MergeHistory(history);
        }


        /// <summary>
        /// Retrieves all encounter histories for all translation pairs in this history collection.
        /// </summary>
        /// <returns>
        /// All encounter histories for all translation pairs in this history collection.
        /// </returns>
        public IEnumerable<EncounterHistory> GetAllEncounterHistories()
        {
            return pairs.Select(kvp => kvp.Value);
        }

        // ====================
        // OVERRIDES/IMPLEMENTS
        // ====================

        /// <inheritdoc/>
        /// <remarks>
        /// Example structure:
        /// <code>
        /// {
        ///   [pairId1]: {
        ///       // Object that results from EncounterHistory.toJSON()
        ///   },
        ///   [pairId2]: {
        ///      // Object that results from EncounterHistory.toJSON()
        ///   },
        ///   // ...
        /// }
        /// 
        /// </code>
        /// </remarks>
        public JSONObject ToJSON()
        {
            JSONObject history = new JSONObject(JSONObject.Type.OBJECT);
            foreach (KeyValuePair<ParseObjectId, EncounterHistory> kvp in pairs)
                history.AddField(kvp.Key.ToString(), kvp.Value.ToJSON());

            return history;
        }
    }
}