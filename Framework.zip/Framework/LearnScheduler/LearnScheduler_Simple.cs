﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cabuu.Data;

namespace Cabuu.Coach
{
    public sealed class LearnScheduler_Simple : LearnScheduler
    {
        // CONSTANTS
        private const int DEFAULT_TEST_DAYS = 2;
        private const int DEFAULT_WORDS_PER_DAY = 8;

        public static readonly Func<int, int> RECOMMENDED_DAYS =
            (words) => DEFAULT_TEST_DAYS + (int) Math.Ceiling((float) words / DEFAULT_WORDS_PER_DAY);

        // ====================
        // CONSTRUCTORS
        // ====================

        private LearnScheduler_Simple(LearningList learnList, LearnProfile profile, UserSettings settings, DateTime startDate, DateTime dueDate)
            : base(learnList, profile, settings, startDate, dueDate)
        {
        }
        private LearnScheduler_Simple(LearningList learnList, LearnProfile profile, UserSettings settings, DateTime startDate, DateTime dueDate,
                                      IEnumerable<LearnEvent> learnEvents)
            : base(learnList, profile, settings, startDate, dueDate, learnEvents)
        {
        }


        // ====================
        // STATIC CONSTRUCTORS
        // ====================

        /// <summary>
        /// Constructs a new learning scheduler object with the given values, and generates the new event schedule.
        /// </summary>
        /// <param name="learnList">The learning list to create the schedule for.</param>
        /// <param name="profile">The learning profile of the user for the relevant language pair.</param>
        /// <param name="settings">Settings for the user.</param>
        /// <param name="startDate">The starting date of the learning schedule.</param>
        /// <param name="dueDate">The due date of the learning schedule.</param>
        /// <returns>
        /// The newly constructed <see cref="LearnScheduler_Simple"/> object.
        /// </returns>
        public static LearnScheduler Build(LearningList learnList, LearnProfile profile, UserSettings settings, DateTime startDate, DateTime dueDate)
        {
            return new LearnScheduler_Simple(learnList, profile, settings, startDate, dueDate).GenerateSchedule();
        }

        /// <summary>
        /// Constructs a new learning scheduler object with the given values, using the given learning events as the schedule.
        /// </summary>
        /// <param name="learnList">The learning list to create the schedule for.</param>
        /// <param name="profile">The learning profile of the user for the relevant language pair.</param>
        /// <param name="settings">Settings for the user.</param>
        /// <param name="startDate">The starting date of the learning schedule.</param>
        /// <param name="dueDate">The due date of the learning schedule.</param>
        /// <param name="learnEvents">A list of learning events to populate the schedule with.</param>
        /// <returns>
        /// The newly constructed <see cref="LearnScheduler_Simple"/> object.
        /// </returns>
        public static LearnScheduler Build(LearningList learnList, LearnProfile profile, UserSettings settings, DateTime startDate, DateTime dueDate,
                                           IEnumerable<LearnEvent> learnEvents)
        {
            return new LearnScheduler_Simple(learnList, profile, settings, startDate, dueDate, learnEvents);
        }


        /// <summary>
        /// Creates a new learning scheduler object using the values contained in the given learning scheduler JSON object.
        /// If the JSON could not be successfully parsed, throws a <see cref="JSONException"/>.
        /// </summary>
        /// <param name="lists">Collection of learning lists that allow a Parse object ID of a learning list to be resolved.</param>
        /// <param name="learnProfiles">Collection of learning profiles that allow a Parse object ID of a learning profile to be resolved.</param>
        /// <param name="obj">JSON object in the form as created by <see cref="LearnScheduler.ToJSON"/></param>
        /// <returns>
        /// The newly constructed <see cref="LearnScheduler_Simple"/> object.
        /// </returns>
        public static LearnScheduler FromJSON(ParseObjectCollection<LearningList> lists,
                                              ParseObjectCollection<LearnProfile> learnProfiles,
                                              JSONObject obj)
        {
            if (obj == null || !obj.IsObject || !obj.HasFields(FIELDS))
                throw JSONUtils.GenericParsingError(obj, typeof(LearnScheduler_Simple));

            LearnProfile learnProfile = learnProfiles.Get(obj.GetString(FIELD_PROFILE_ID));
            LearningList ll = lists.Get(obj.GetString(FIELD_LIST_ID));

            return FromJSON(ll, learnProfile, obj);
        }


        /// <summary>
        /// Creates a new learning scheduler object using the values contained in the given learning scheduler JSON object.
        /// If the JSON could not be successfully parsed, throws a <see cref="JSONException"/>.
        /// </summary>
        /// <param name="list">Learning list for the scheduler.</param>
        /// <param name="learnProfile">Learn profile for the scheduler.</param>
        /// <param name="obj">JSON object in the form as created by <see cref="LearnScheduler.ToJSON"/></param>
        /// <returns>
        /// The newly constructed <see cref="LearnScheduler_Simple"/> object.
        /// </returns>
        public static LearnScheduler FromJSON(LearningList list, LearnProfile learnProfile, JSONObject obj)
        {
            if (obj == null || !obj.IsObject || !obj.HasFields(FIELDS))
                throw new JSONException("[LearnScheduler] JSON object could not be parsed.");

            if (learnProfile == null || list == null)
                throw new JSONException("[LearnScheduler] Parse object ID for learning list or learning profile could not be resolved.");

            return Build(list,
                         learnProfile,
                         UserSettings.FromJSON(obj.GetJSONObject(FIELD_SETTINGS)),
                         obj.GetTimestamp(FIELD_START_DATE),
                         obj.GetTimestamp(FIELD_END_DATE),
                         obj.GetJSONArray(FIELD_EVENTS)
                            .list.Select(x => LearnEvent_Simple.FromJSON(learnProfile, x)));
        }


        // ====================
        // OVERRIDES/IMPLEMENTS
        // ====================

        /// <inheritdoc />
        /// <remarks>
        /// For <see cref="LearnScheduler_Simple"/>, does nothing.
        /// </remarks>
        public override void UpdateEvent(LearnEvent learnEvent)
        {
        }


        /// <inheritdoc />
        /// <remarks>
        /// For <see cref="LearnScheduler_Simple"/>, creates a new <see cref="LearnEvent_Simple"/>.
        /// </remarks>
        protected override LearnEvent GetNewLearnEvent(EventType type, DateTime date, IEnumerable<ParseObjectId> pairIds)
        {
            return LearnEvent_Simple.Build(EventId.New(), type, date, EventStatus.PENDING, Profile, pairIds);
        }

        /// <inheritdoc/>
        protected override LearnScheduler GenerateSchedule()
        {
            List<TranslationPair> translationPairs = LearnList.AllTranslationPairs
                                                              .ToList();
            // Store the total pair count
            int pairCount = translationPairs.Count;
            // Calculate the number of days available for studying (including startDate AND dueDate)
            int days = DateUtils.DaysBetween(StartDate, DueDate) + 1;

            // If the dueDate is today (or in the past?), add a big study and test session for today, then be done.
            if (days <= 1)
            {
                AddEvents(StudyAndTest(StartDate,
                                       LearnList.AllTranslationPairs.Select(x => x.ObjectId),
                                       LearnList.AllTranslationPairs.Select(x => x.ObjectId)));

                SortEvents();

                return this;
            }

            // Calculate the recommended number of days for the number of pairs being learned.
            int recommendedDays = RECOMMENDED_DAYS(pairCount);


            // ** OUTPUT FOR TESTING
            /*
            Debug.Log(string.format("Generating schedule for ({0}) pairs over ({1}) days.  Recommended days for " +
                                             "this amount of pairs:  {2}",
                                             pairCount, days, recommendedDays));
            Debug.Log("=====================\n");
            */


            // Find the number of appropriate exam days... if there are fewer days to learn than the default number
            // of exam days, have only one test.  Otherwise, have the default number of exams.
            int examDays = days <= DEFAULT_TEST_DAYS
                               ? 1
                               : DEFAULT_TEST_DAYS;

            // Find the average number of pairs per day to learn.  If we have to learn at an accelerated rate,
            // increase the pairs-per-day over the default, otherwise use the default.
            int wordsPerDay = days <= recommendedDays
                                  ? (int) Math.Ceiling((float) pairCount / (days - examDays))
                                  : DEFAULT_WORDS_PER_DAY;

            // Find the fractional interval between days to add to the schedule.  If the schedule duration is less than or
            // equal to the recommended, this should equal exactly one.  Otherwise, this should be some value > 1.
            // Example:  dayInterval = 1.5, this means that there should be 2 study sessions every 3 days.
            // Example:  dayInterval = 3, this means that there should be 1 study session every 3 days.
            float dayInterval = (days - examDays) / ((float) Math.Ceiling((float) pairCount / wordsPerDay));

            // List for temporarily holding onto the study sessions generated, used for referring to when determining
            // what pairs to test in testing events.
            List<LearnEvent> studyEvents = new List<LearnEvent>();

            // Boolean for tracking when a particular day should be a study day and when not.
            bool shouldStudy = true;

            // Iterate through the full length of the schedule, incrementing by the dayInterval.
            for (float dayOffset = 0f; dayOffset < days; dayOffset += dayInterval)
            {
                DateTime dt = StartDate.Date.AddDays((int) dayOffset); // day offset rounded down to nearest integer

                // ** OUTPUT FOR TESTING
                // Debug.Log("DAY " + (int)(dayOffset + 1) + ":\n-------------");

                // See if the current day offset is appropriate for creating an exam event.  If so, an exam event is created
                // and added to the event list, and this iteration of the loop is done (going to the next day offset).
                if (AddExam(days, examDays, dayOffset, dayInterval, dt))
                {
                    // ** OUTPUT FOR TESTING
                    /*
                    System.out.println(String.format("Exam added (%d pairs).\n",
                                                     eventMap.get(eventOrder.get(eventOrder.Count - 1)).getParseObjectIds().Count));
                                                     */
                    // Ensure the next event is a study event
                    // ** ACTUALLY NOT **  shouldStudy = true;
                    continue;
                }

                if (shouldStudy)
                {
                    // Get the list of pairs to study by pulling a sublist out of the complete pair list
                    // Grab an amount of pairs equal to double the pairs-per-day

                    int start = Math.Min(studyEvents.Count * wordsPerDay * 2,
                                         translationPairs.Count - 1);

                    List<ParseObjectId> studyPairs = translationPairs
                                                     .GetRange(start,
                                                               Math.Min(wordsPerDay * 2,
                                                                        translationPairs.Count - start))
                                                     .Select(x => x.ObjectId)
                                                     .ToList();


                    // Generate the study event
                    LearnEvent learnEvent = GetNewLearnEvent(EventType.LEARN, dt, studyPairs).RecalculateOrdering();
                    // Add the study event to the study events list
                    studyEvents.Add(learnEvent);
                    // Add the event to the master list of events
                    AddEvent(learnEvent);

                    // Ensure the next event is not a study event
                    shouldStudy = false;


                    // ** OUTPUT FOR TESTING
                    /*
                    System.out.println(String.format("Study session added (%d pairs).  Words: [%s]",
                                                     studyPairs.Count,
                                                     StringUtils.join(studyPairs.stream()
                                                                                .map(w->w.id)
                                                                                .sorted((s1, s2)->Integer.parseInt(s1) -
                                                                                        Integer.parseInt(s2))
                                                                                .collect(Collectors.toList()),
                                                                      " ")));

                    System.out.println(); */
                }
                else
                {
                    List<ParseObjectId> testPairs = new List<ParseObjectId>();

                    // This incrementer is doubled with each pass of the loop, resulting in an increasing interval between
                    // study sessions where testing pairs are taken from.
                    // Where N = (the number of study events), the study events chosen will be:
                    // N, N - 1, N - 3, N - 7, N - 15, etc.
                    int inc = 1;
                    for (int i = studyEvents.Count - 1; i >= 0; i -= inc, inc *= 2)
                    {
                        // Add the pairs from the selected study session to this testing session
                        testPairs.AddRange(studyEvents[i].GetTranslationPairIDs());
                    }

                    // Generate the test event and add it to the master list of events
                    AddEvent(GetNewLearnEvent(EventType.TEST, dt, testPairs).RecalculateOrdering());


                    // Ensure the next non-exam event is a study event
                    shouldStudy = true;


                    // ** OUTPUT FOR TESTING
                    /*
                    System.out.println(String.format("Test session added (%d pairs).  Words: [%s]",
                                                     testPairs.Count,
                                                     StringUtils.join(testPairs.stream()
                                                                               .map(w->w.id)
                                                                               .sorted((s1, s2)->Integer.parseInt(s1) -
                                                                                       Integer.parseInt(s2))
                                                                               .collect(Collectors.toList()),
                                                                      " ")));
                    System.out.println(); */
                }
            }


            // Return this LearnScheduler object to facilitate chaining
            return this;
        }

        /// <summary>
        /// Tests if adding an exam to the schedule is appropriate for the given day offset.  If the day is determined to
        /// be an exam day, a test event is added to the schedule with all pairs thus far learned, and this method returns
        /// true.  Otherwise, no events are added and this method returns false.
        /// </summary>
        ///
        /// <param name="days">Total number of days to schedule for</param>
        /// <param name="examDays">The number of test days to schedule</param>
        /// <param name="dayOffset">The current day offset</param>, representing the day to schedule events for
        /// <param name="dayInterval">The amount that schedule days are incremented by</param>
        /// <param name="date">The DateTime to set as the event date</param>, if an event is scheduled.
        /// <returns> 
        /// Returns true if a test event was scheduled, false otherwise.
        /// </returns>
        private bool AddExam(int days, int examDays, float dayOffset, float dayInterval, DateTime date)
        {
            // Iterate through all exam days
            for (int i = 1; i <= examDays; i++)
            {
                // Calculate the appropriate day offset for this exam
                float examOffset = i * ((float) (days - (examDays - i) - 1) / examDays);

                // If the exam's offset is in the future compared to the given day offset, break the loop as there
                // is no longer any reason to search.
                if (examOffset > dayOffset)
                    break;

                // If the exam's offset is in the past compared to the given day offset, but in the future compared
                // to the previous day offset, then this day must be an exam day.  Add an exam event and return true.
                if (examOffset >= dayOffset - dayInterval)
                {
                    AddEvent(GetNewLearnEvent(EventType.EXAM,
                                              date,
                                              events.SelectMany(x => x.Value.GetTranslationPairIDs()))
                                 .RecalculateOrdering());
                    return true;
                }
            }

            // If the given day was not suitable for an exam, then return false.
            return false;
        }

        /// <summary>
        /// Generates a study event and a test event both on the same given date, using their own pair lists as given.
        /// The study event is scheduled 1 minute prior to the testing event just to ensure appropriate ordering of
        /// events.
        /// </summary>
        /// 
        /// <param name="date">The DateTime to schedule both the studying and the testing events on</param>.
        /// <param name="studyPairs">The pairs to introduce in the study session</param>.
        /// <param name="testPairs">The pairs to review in the testing session</param>.
        /// <returns>
        /// A list containing 2 learn events; the first one being a study event, and the second a testing event.
        /// </returns>
        private IEnumerable<LearnEvent> StudyAndTest(DateTime date, IEnumerable<ParseObjectId> studyPairs, IEnumerable<ParseObjectId> testPairs)
        {
            List<LearnEvent> ev = new List<LearnEvent>();

            // Hours and minutes are irrelevant for scheduling; only day matters.  Minutes do help ordering of events
            // within the day, however.
            DateTime d = date.Date.AddDays(1).AddSeconds(-2);

            // Generate the study event
            ev.Add(GetNewLearnEvent(EventType.LEARN, d, studyPairs));

            d = d.AddSeconds(1);

            // Generate the testing event
            ev.Add(GetNewLearnEvent(EventType.TEST, d, testPairs));

            // Return both created events
            return ev;
        }
    }
}