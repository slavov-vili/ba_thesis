﻿
using System;
using System.Collections.Generic;
using System.Linq;
using Cabuu.Data;

namespace Cabuu.Coach
{
    public abstract class LearnScheduler : IJsonable
    {

        protected readonly ComparisonComparer<EventId> EVENT_COMPARER;  // Defined in constructor

        // CONSTANTS
        protected const string FIELD_SETTINGS = "settings";
        protected const string FIELD_PROFILE_ID = "learnProfileId";
        protected const string FIELD_LIST_ID = "listId";
        protected const string FIELD_START_DATE = "startDate";
        protected const string FIELD_END_DATE = "dueDate";
        protected const string FIELD_EVENTS = "events";

        protected static readonly string[] FIELDS =
        {
            FIELD_SETTINGS, FIELD_PROFILE_ID, FIELD_LIST_ID, FIELD_START_DATE, FIELD_END_DATE, FIELD_EVENTS
        };


        // MEMBERS
        public readonly LearnProfile Profile;
        public readonly LearningList LearnList;
        public readonly DateTime StartDate;
        public readonly DateTime DueDate;  // TODO:  Maybe make not readonly?
        public readonly UserSettings Settings;
        protected readonly Dictionary<EventId, LearnEvent> events = new Dictionary<EventId, LearnEvent>();

        
        // This is here to cache the sorted order of the events, while maintaining the above map for O(1) event access.
        // This is a list of event IDs rather than the events themselves so that entries in the map can be entirely
        // replaced without needing to also update this list.
        protected readonly List<EventId> eventOrdering = new List<EventId>();
        

        // ====================
        // ABSTRACT METHODS
        // ====================

        /// <summary>
        /// Updates an event, replacing the event in the LearnEvent collection with the matching unique identifier.
        /// This triggers a reevaluation of the entire schedule, resulting in future events being potentially
        /// changed.  This should be called whenever an event has been completed (or skipped) by a user.
        /// </summary>
        /// <param name="learnEvent">The learning event to update.</param>
        public abstract void UpdateEvent(LearnEvent learnEvent);

        /// <summary>
        /// Produces the full schedule of learning events, including the date they are to take place on and the 
        /// translation pairs they are to present.
        /// </summary>
        /// <returns>
        /// Returns this learning scheduler in order to facilitate chaining.
        /// </returns>
        protected abstract LearnScheduler GenerateSchedule();

        /// <summary>
        /// Constructs a new learning event of a particular type, as dictated by the scheduler subclass implementing this.
        /// </summary>
        /// <param name="type">The type of event to create.</param>
        /// <param name="date">The date to schedule the event for.</param>
        /// <param name="pairIds">The translation pairs to include in the event.</param>
        /// <returns>
        /// A newly constructed learning event.
        /// </returns>
        protected abstract LearnEvent GetNewLearnEvent(EventType type, DateTime date, IEnumerable<ParseObjectId> pairIds);

        // ====================
        // CONSTRUCTORS
        // ====================

        protected LearnScheduler(LearningList learnList, LearnProfile profile, UserSettings settings, DateTime startDate, DateTime dueDate)
        {
            Profile = profile;
            LearnList = learnList;
            Settings = settings;
            StartDate = startDate;
            DueDate = dueDate;

            EVENT_COMPARER = new ComparisonComparer<EventId>((x, y) => events[x].Date.CompareTo(events[y].Date));
        }

        protected LearnScheduler(LearningList learnList, LearnProfile profile, UserSettings settings, DateTime startDate, DateTime dueDate,
                                 IEnumerable<LearnEvent> learnEvents)
            : this(learnList, profile, settings, startDate, dueDate)
        {
            foreach (LearnEvent le in learnEvents)
            {
                events.Add(le.Id, le);
                eventOrdering.Add(le.Id);
            }

            SortEvents();
        }


        // ====================
        // METHODS (MAY BE OVERRIDEN BY SUBCLASSES)
        // ====================

        /// <summary>
        /// Retrieves the full schedule from this scheduler.  All events are returned in chronological order.
        /// </summary>
        /// <returns>
        /// A chronologically-sorted list of all scheduled learn events.
        /// </returns>
        public virtual List<LearnEvent> GetSchedule()
        {
            return eventOrdering.Select(x => events[x]).ToList();
        }


        /// <summary>
        /// Retrieves the next learning event in the schedule in relation to the current time.
        /// </summary>
        /// <returns>
        /// The next future learning event.  If there are no future events, then returns null.
        /// </returns>
        public virtual LearnEvent GetNextEvent()
        {
            return GetEventAfter(DateTime.Now);
        }


        /// <summary>
        /// Retrieves the next learning event in the schedule in relation to the given timestamp.
        /// </summary>
        /// <param name="date">The timestamp to compare against.</param>
        /// <returns>
        /// The next learning event after the given timestamp.  If there are no following events, then returns null.
        /// </returns>
        public virtual LearnEvent GetEventAfter(DateTime date)
        {
            int index = BinarySearchDate(date);
            
            return index < eventOrdering.Count ? events[eventOrdering[index]] : null;

            /*
            foreach (EventId id in eventOrdering)
            {

                if (date < events[id].Date)
                    return events[id];
            }
            return null;
            */

        }

        /// <summary>
        /// Retrieves a collection of events that occur on the same day as the given date.
        /// </summary>
        /// <param name="date">The date to get events for.</param>
        /// <returns>
        /// A collection of events for the given date.
        /// </returns>
        public virtual IEnumerable<LearnEvent> GetEventsOnDate(DateTime date)
        {
            int index = BinarySearchDate(date.Date);

            for (var i = index; i < eventOrdering.Count && DateUtils.IsSameDay(events[eventOrdering[i]].Date, date); i++)
                yield return events[eventOrdering[i]];

            /*
            return eventOrdering.FindAll(x => DateUtils.IsSameDay(date, events[x].Date))
                                .Select(x => events[x]);
                                */
        }


        /// <summary>
        /// Retrieves the first learning event to occur on the given date.
        /// </summary>
        /// <param name="date">The date to get events for.</param>
        /// <returns>
        /// The first learning event on the given date.  If there are no events on the given date, returns null.
        /// </returns>
        public virtual LearnEvent GetFirstEventOnDate(DateTime date)
        {
            return GetEventAfter(date.Date);
        }


        /// <summary>
        /// Retrieves the number of learning days in the schedule.  This is calculated as the difference in days between
        /// the starting date and the due date, plus one (to include both starting and ending days).
        /// </summary>
        /// <returns>
        /// The total number of learning days in the schedule.
        /// </returns>
        public virtual int NumberOfDaysInSchedule()
        {
            return DateUtils.DaysBetween(StartDate, DueDate) + 1;
        }


        /// <summary>
        /// Calculates the percentage of progress the user has made on this schedule.  By default, this is calculated simply
        /// by the current time as compared to the start and due dates of the schedule, but may be overriden by subclasses
        /// for a more sophisticated calculation.
        /// </summary>
        /// <returns>
        /// The percentage of progress made on this learning schedule, between 0 and 1, inclusive.
        /// </returns>
        public virtual float GetProgress()
        {
            return DateUtils.DaysBetween(StartDate, DateTime.Today) / (float)NumberOfDaysInSchedule();
        }



        // ====================
        // PRIVATE METHODS (MAY BE OVERRIDDEN BY SUBCLASSES)
        // ====================


        /// <summary>
        /// Utility method for triggering the sorting of all events chronologically.
        /// </summary>
        protected void SortEvents()
        {
            eventOrdering.Sort((x, y) => events[x].Date.CompareTo(events[y].Date));
        }


        /// <summary>
        /// Adds the given event to the schedule if it is not already present.  Otherwise, does nothing.
        /// </summary>
        /// <param name="learnEvent">The event to add to the schedule.</param>
        protected virtual void AddEvent(LearnEvent learnEvent)
        {
            if (events.ContainsKey(learnEvent.Id)) return;

            events[learnEvent.Id] = learnEvent;

            EVENT_COMPARER.BinaryInsertion(learnEvent.Id, eventOrdering);
        }


        /// <summary>
        /// Adds the given events to the schedule if they are not already present.  Otherwise, does nothing.
        /// </summary>
        /// <param name="learnEvents">The events to add to the schedule.</param>
        protected virtual void AddEvents(IEnumerable<LearnEvent> learnEvents)
        {
            foreach (LearnEvent le in learnEvents)
                AddEvent(le);
        }

        /// <summary>
        /// Performs an O(log n) binary search of the events ordering to find the first event that falls after 
        /// the given timestamp, returning its index.
        /// </summary>
        /// <param name="date">The timestamp to search in relation to</param>
        /// <returns>
        /// The index of the first learn event that falls after the given timestamp.
        /// </returns>
        protected virtual int BinarySearchDate(DateTime date)
        {
            int left = 0;
            int right = eventOrdering.Count - 1;

            while (left < right)
            {
                int middle = (int)Math.Floor((double)(left + right) / 2);

                int comparison = events[eventOrdering[middle]].Date.CompareTo(date);
                if (comparison < 0)
                    left = middle + 1;
                else if (comparison > 0)
                    right = middle - 1;
                else
                    return middle;
            }

            return right + 1;
        }

        // ====================
        // OVERRIDES/IMPLEMENTS
        // ====================


        /// <inheritdoc/>
        /// <remarks>
        /// Example structure:
        /// <code>
        /// {
        ///   "settings": {
        ///     // Object resulting from UserSettings.ToJSON()
        ///   },
        ///   "learnProfileId": "string", // Unique ID of the learning profile
        ///   "listId": "string", // Unique ID of learning list
        ///   "startDate": "string", // String representation of the start date
        ///   "dueDate": "string", // String representation of the due date
        ///   "events": [
        ///       // Objects that result from LearnEvent.toJSON()
        ///   ]
        /// }
        /// 
        /// </code>
        /// </remarks>
        public virtual JSONObject ToJSON()
        {
            JSONObject obj = new JSONObject(JSONObject.Type.OBJECT);

            obj.AddField(FIELD_SETTINGS, Settings.ToJSON());
            obj.AddField(FIELD_PROFILE_ID, Profile.ObjectId.Id);
            obj.AddField(FIELD_LIST_ID, LearnList.ObjectId.Id);
            obj.AddField(FIELD_START_DATE, StartDate.Stringify());
            obj.AddField(FIELD_END_DATE, DueDate.Stringify());

            JSONObject arr = new JSONObject(JSONObject.Type.ARRAY);
            foreach (EventId id in eventOrdering)
                arr.Add(events[id].ToJSON());

            obj.AddField(FIELD_EVENTS, arr);

            return obj;
        }
    }
}
