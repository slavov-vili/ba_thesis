﻿
using Cabuu;

public class UserSettings : IJsonable {
    public JSONObject ToJSON()
    {
        return new JSONObject(JSONObject.Type.OBJECT);
    }

    public static UserSettings FromJSON(JSONObject obj)
    {
        return new UserSettings();
    }

    public static UserSettings Build()
    {
        return new UserSettings();
    }
}
