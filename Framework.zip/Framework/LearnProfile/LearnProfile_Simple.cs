﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cabuu.Data;
using SimpleSQL;

namespace Cabuu.Coach
{
    public sealed class LearnProfile_Simple : LearnProfile
    {
        // ====================
        // CONSTRUCTORS
        // ====================

        private LearnProfile_Simple(ParseObjectId objectId, ParseObjectId userId, Language sourceLang, Language targetLang,
                                    IEnumerable<EncounterHistory> pairs, DateTime updatedAt)
            : base(objectId, userId, sourceLang, targetLang, pairs, updatedAt)
        {
        }
        private LearnProfile_Simple(string objectId, string userId, string sourceLang, string targetLang,
                                    IEnumerable<EncounterHistory> pairs, DateTime updatedAt)
            : base(objectId, userId, sourceLang, targetLang, pairs, updatedAt)
        {
        }


        // ====================
        // STATIC CONSTRUCTORS
        // ====================

        /// <summary>
        /// Constructs a new learning profile object with the given values.
        /// </summary>
        /// <param name="objectId">Parse object ID of the learning profile.</param>
        /// <param name="userId">Parse object ID of the user to whom the profile belongs.</param>
        /// <param name="sourceLang">The source language of the learning profile.</param>
        /// <param name="targetLang">The target language of the learning profile.</param>
        /// <param name="pairs">Encounter histories with all encountered translation pairs.</param>
        /// <param name="updatedAt">Timestamp of the object's last update</param>
        /// <returns>
        /// The newly constructed <see cref="LearnProfile"/> object.
        /// </returns>
        public static LearnProfile Build(ParseObjectId objectId, ParseObjectId userId, Language sourceLang, Language targetLang,
                                         IEnumerable<EncounterHistory> pairs, DateTime updatedAt)
        {
            return new LearnProfile_Simple(objectId, userId, sourceLang, targetLang, pairs, updatedAt);
        }

        /// <summary>
        /// Constructs a new learning profile object with the given values.
        /// </summary>
        /// <param name="objectId">Parse object ID of the learning profile.</param>
        /// <param name="userId">Parse object ID of the user to whom the profile belongs.</param>
        /// <param name="sourceLang">The source language of the learning profile.</param>
        /// <param name="targetLang">The target language of the learning profile.</param>
        /// <param name="pairs">Encounter histories with all encountered translation pairs.</param>
        /// <param name="updatedAt">Timestamp of the object's last update</param>
        /// <returns>
        /// The newly constructed <see cref="LearnProfile"/> object.
        /// </returns>
        public static LearnProfile Build(string objectId, string userId, string sourceLang, string targetLang,
                                         IEnumerable<EncounterHistory> pairs, DateTime updatedAt)
        {
            return Build(ParseObjectId.Of(objectId), ParseObjectId.Of(userId),
                         LanguageUtils.Parse(sourceLang), LanguageUtils.Parse(targetLang), pairs, updatedAt);
        }

        /// <summary>
        /// Constructs a brand new learning profile for the user for the given language pair.
        /// </summary>
        /// <param name="userId">Parse object ID of the user to whom the profile belongs.</param>
        /// <param name="sourceLang">The source language of the learning profile.</param>
        /// <param name="targetLang">The target language of the learning profile.</param>
        /// <returns>
        /// The newly constructed <see cref="LearnProfile"/> object.
        /// </returns>
        public static LearnProfile BuildNew(ParseObjectId userId, Language sourceLang, Language targetLang)
        {
            return Build(ParseObjectId.Empty(), userId, sourceLang, targetLang,
                         Enumerable.Empty<EncounterHistory>(), DateTime.Now);
        }

        /// <summary>
        /// Constructs a brand new learning profile for the user for the given language pair.
        /// </summary>
        /// <param name="userId">Parse object ID of the user to whom the profile belongs.</param>
        /// <param name="sourceLang">The source language of the learning profile.</param>
        /// <param name="targetLang">The target language of the learning profile.</param>
        /// <returns>
        /// The newly constructed <see cref="LearnProfile"/> object.
        /// </returns>
        public static LearnProfile BuildNew(string userId, string sourceLang, string targetLang)
        {
            return BuildNew(ParseObjectId.Of(userId),
                            LanguageUtils.Parse(sourceLang),
                            LanguageUtils.Parse(targetLang));
        }

        /// <summary>
        /// Constructs a new simple learning profile object using the values contained in the given 
        /// learning profile JSON object.
        /// If the JSON could not be successfully parsed, throws a <see cref="JSONException"/>.
        /// </summary>
        /// <param name="obj">JSON object in the form as created by <see cref="LearnProfile.ToJSON"/></param>
        /// <returns>
        /// The newly constructed <see cref="LearnProfile_Simple"/> object.
        /// </returns>
        public static LearnProfile FromJSON(JSONObject obj)
        {
            if (obj == null || !obj.IsObject || !obj.HasFields(FIELDS) || !obj[FIELD_INFO].HasFields(INFO_FIELDS))
                throw JSONUtils.GenericParsingError(obj, typeof(LearnProfile_Simple));


            JSONObject historyObj = obj.GetJSONObject(FIELD_INFO).GetJSONObject(FIELD_INFO_HISTORY);
            return Build(obj.GetParseObjectId(FIELD_OBJECT_ID),
                         obj.GetParseObjectId(FIELD_USER_ID),
                         obj.GetLanguage(FIELD_SOURCE_LANG),
                         obj.GetLanguage(FIELD_TARGET_LANG),
                         historyObj.keys.Select(x => EncounterHistory_Simple.FromJSON(historyObj.GetJSONObject(x))),
                         obj.GetTimestamp(FIELD_UPDATEDAT));
        }


        // ====================
        // OVERRIDES/IMPLEMENTS
        // ====================

        /// <inheritdoc/>
        /// <remarks>
        /// For <see cref="LearnProfile_Simple"/>, simply returns an average of the competency evaluations for
        /// each component translation pair's encounter history.
        /// </remarks>
        public override float EvaluateCompetency()
        {
            return History.GetAllEncounterHistories()
                          .Select(h => h.GetCompetency())
                          .DefaultIfEmpty(0f)
                          .Average();
        }

        /// <inheritdoc/>
        /// <remarks>
        /// For <see cref="LearnProfile_Simple"/>, returns a <see cref="EncounterHistory_Simple"/>.
        /// </remarks>
        public override EncounterHistory BuildEmptyHistory(ParseObjectId pairId)
        {
            return EncounterHistory_Simple.Build(pairId);
        }

        /// <inheritdoc/>
        public override ISqlWrapper<LearnProfile> Wrap()
        {
            if (SavedRemote)
                return LearnProfileData.Wrap(this);
            else
                return LearnProfileDataLocalOnly.Wrap(this);
        }

        /// <inheritdoc/>
        public override string SqlTableName
        {
            get { return SavedRemote ? typeof(LearnProfileData).Name : typeof(LearnProfileDataLocalOnly).Name; }
        }

        /// <inheritdoc/>
        public override string SqlUniqueColumnName
        {
            get { return SavedRemote ? "ObjectId" : "SqlKey"; }
        }

        /// <inheritdoc/>
        public override object SqlUniqueColumnValue
        {
            get
            {
                if (SavedRemote)
                    return ObjectId.Id;
                else
                    return SqlKey ?? -1;
            }
        }


        // ====================
        // PUSH/PULL BUILDER METHODS
        // ====================

        /// <summary>
        /// Builds an empty <see cref="PullParams{LearnProfile, LearnProfileData}"/> object with no
        /// filtering parameters for remotely-saved learning profiles.
        /// </summary>
        /// <returns>
        /// The constructed pull parameters object.
        /// </returns>
        public static PullParams<LearnProfile, LearnProfileData> GetPullParams()
        {
            return PullParams<LearnProfile, LearnProfileData>.Build();
        }

        /// <summary>
        /// Builds an empty <see cref="PullParams{LearnProfile, LearnProfileData}"/> object with no
        /// filtering parameters for local-only learning profiles.
        /// </summary>
        /// <returns>
        /// The constructed pull parameters object.
        /// </returns>
        public static PullParams<LearnProfile, LearnProfileDataLocalOnly> GetPullParamsLocalOnly()
        {
            return PullParams<LearnProfile, LearnProfileDataLocalOnly>.Build();
        }

        /// <summary>
        /// Builds a basic <see cref="PushParams{LearnProfile}"/> object out of this learning profile.
        /// </summary>
        /// <returns>
        /// The constructed push parameters object.
        /// </returns>
        public override PushParams<LearnProfile> GetPushParams()
        {
            return PushParams<LearnProfile>.With(this);
        }


        // ====================
        // SQL WRAPPER CLASSES
        // ====================


        /// <summary>
        /// SQL wrapper class for <see cref="LearnProfile"/> objects.
        /// </summary>
        public class LearnProfileData : ISqlWrapper<LearnProfile>
        {
            [PrimaryKey]
            public string ObjectId { get; set; }

            public string UserId { get; set; }

            [Indexed]
            public string SourceLang { get; set; }

            [Indexed]
            public string TargetLang { get; set; }

            public string Info { get; set; }

            public string UpdatedAt { get; set; }

            [Indexed]
            public bool DeletionPending { get; set; }


            public LearnProfileData()
            {
            }


            // ====================
            // STATIC CONSTRUCTOR
            // ====================

            /// <summary>
            /// Wraps an existing <see cref="LearnProfile"/> object into an <see cref="ISqlWrapper{T}"/>.
            /// </summary>
            /// <param name="obj">The object to wrap.</param>
            /// <returns>
            /// The newly constructed wrapper object.
            /// </returns>
            public static LearnProfileData Wrap(LearnProfile obj)
            {
                var json = new JSONObject(JSONObject.Type.OBJECT);
                json.AddField(FIELD_INFO_COMPETENCY, obj.EvaluateCompetency());
                json.AddField(FIELD_INFO_HISTORY, obj.History.ToJSON());

                return new LearnProfileData()
                       {
                           ObjectId = obj.ObjectId.Id,
                           UserId = obj.UserId.Id,
                           SourceLang = obj.SourceLang.Stringify(),
                           TargetLang = obj.TargetLang.Stringify(),
                           Info = json.Print(),
                           UpdatedAt = obj.UpdatedAt.Stringify(),
                           DeletionPending = obj.DeletionPending
                       };
            }


            // ====================
            // METHODS
            // ====================


            /// <summary>
            /// Builds an instance of an <see cref="LearnProfile"/> object based on the contents of this SQL
            /// wrapper.
            /// </summary>
            /// <returns>
            /// The learning profile object represented by this SQL wrapper.
            /// </returns>
            /// <exception cref="InvalidOperationException">
            /// If not all fields of this wrapper are properly initialized, throws an exception.
            /// </exception>
            public LearnProfile Build()
            {
                if (ObjectId == null || UserId == null || SourceLang == null || TargetLang == null || Info == null || UpdatedAt == null)
                    throw new InvalidOperationException(string.Format("[{0}] Illegal state for object construction:  not all fields filled.",
                                                                      this.GetType().FullName));

                var json = new JSONObject(Info);

                var historyJSON = json.HasField(FIELD_INFO_HISTORY)
                                      ? json.GetJSONObject(FIELD_INFO_HISTORY)
                                      : new JSONObject();

                var lp = LearnProfile_Simple.Build(ParseObjectId.Of(ObjectId),
                                                   ParseObjectId.Of(UserId),
                                                   LanguageUtils.Parse(SourceLang),
                                                   LanguageUtils.Parse(TargetLang),
                                                   historyJSON.keys.Select(hist => EncounterHistory_Simple.FromJSON(historyJSON[hist])),
                                                   DateUtils.Parse(UpdatedAt));
                lp.DeletionPending = DeletionPending;

                return lp;
            }
        }


        /// <summary>
        /// SQL wrapper class for <see cref="LearnProfile"/> objects.
        /// </summary>
        public class LearnProfileDataLocalOnly : ISqlWrapper<LearnProfile>
        {
            [PrimaryKey, AutoIncrement]
            public int SqlKey { get; set; }

            public string UserId { get; set; }

            [Indexed]
            public string SourceLang { get; set; }

            [Indexed]
            public string TargetLang { get; set; }

            public string Info { get; set; }

            public string UpdatedAt { get; set; }


            public LearnProfileDataLocalOnly()
            {
            }


            // ====================
            // STATIC CONSTRUCTOR
            // ====================

            /// <summary>
            /// Wraps an existing <see cref="LearnProfile"/> object into an <see cref="ISqlWrapper{T}"/>.
            /// </summary>
            /// <param name="obj">The object to wrap.</param>
            /// <returns>
            /// The newly constructed wrapper object.
            /// </returns>
            public static LearnProfileDataLocalOnly Wrap(LearnProfile obj)
            {
                var json = new JSONObject(JSONObject.Type.OBJECT);
                json.AddField(FIELD_INFO_COMPETENCY, obj.EvaluateCompetency());
                json.AddField(FIELD_INFO_HISTORY, obj.History.ToJSON());

                var lp = new LearnProfileDataLocalOnly()
                         {
                             UserId = obj.UserId.Id,
                             SourceLang = obj.SourceLang.Stringify(),
                             TargetLang = obj.TargetLang.Stringify(),
                             Info = json.Print(),
                             UpdatedAt = obj.UpdatedAt.Stringify()
                         };
                if (obj.SqlKey != null)
                    lp.SqlKey = (int) obj.SqlKey.Value;

                return lp;
            }


            // ====================
            // METHODS
            // ====================


            /// <summary>
            /// Builds an instance of an <see cref="LearnProfile"/> object based on the contents of this SQL
            /// wrapper.
            /// </summary>
            /// <returns>
            /// The learning profile object represented by this SQL wrapper.
            /// </returns>
            /// <exception cref="InvalidOperationException">
            /// If not all fields of this wrapper are properly initialized, throws an exception.
            /// </exception>
            public LearnProfile Build()
            {
                if (UserId == null || SourceLang == null || TargetLang == null || Info == null || UpdatedAt == null)
                    throw new InvalidOperationException(string.Format("[{0}] Illegal state for object construction:  not all fields filled.",
                                                                      this.GetType().FullName));

                var json = new JSONObject(Info);

                var historyJSON = json.HasField(FIELD_INFO_HISTORY)
                                      ? json.GetJSONObject(FIELD_INFO_HISTORY)
                                      : new JSONObject();

                return LearnProfile_Simple.Build(
                                              ParseObjectId.Empty(),
                                              ParseObjectId.Of(UserId),
                                              LanguageUtils.Parse(SourceLang),
                                              LanguageUtils.Parse(TargetLang),
                                              historyJSON.keys != null
                                                  ? historyJSON.keys.Select(hist => EncounterHistory_Simple.FromJSON(historyJSON[hist]))
                                                  : Enumerable.Empty<EncounterHistory>(),
                                              DateUtils.Parse(UpdatedAt))
                                          .SetSqlKey(SqlKey);
            }
        }
    }
}