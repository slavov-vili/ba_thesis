﻿using System;
using System.Collections.Generic;
using Cabuu.Data;

namespace Cabuu.Coach
{

    public abstract class LearnProfile : IJsonable, ISyncableParseObject, ISqlable<LearnProfile>
    {
        // CONSTANTS
        protected const string FIELD_OBJECT_ID = "objectId";
        protected const string FIELD_USER_ID = "userId";
        protected const string FIELD_SOURCE_LANG = "sourceLang";
        protected const string FIELD_TARGET_LANG = "targetLang";
        protected const string FIELD_INFO = "info";
        protected const string FIELD_INFO_HISTORY = "history";
        protected const string FIELD_INFO_COMPETENCY = "competency";
        protected const string FIELD_UPDATEDAT = "updatedAt";

        protected static readonly string[] FIELDS =
        {
            FIELD_OBJECT_ID, FIELD_USER_ID, FIELD_SOURCE_LANG, FIELD_TARGET_LANG, FIELD_INFO
        };

        protected static readonly string[] INFO_FIELDS =
        {
            FIELD_INFO_COMPETENCY, FIELD_INFO_HISTORY
        };

        public const string COL_OBJECTID = "ObjectId";
        public const string COL_USERID = "UserId";
        public const string COL_SOURCELANG = "SourceLang";
        public const string COL_TARGETLANG = "TargetLang";
        public const string COL_INFO = "Info";
        public const string COL_UPDATEDAT = "UpdatedAt";


        // MEMBERS
        public ParseObjectId ObjectId { get; private set; }
        public readonly ParseObjectId UserId;
        public readonly Language SourceLang, TargetLang;
        public readonly HistoryCollection History;
        public DateTime UpdatedAt { get; private set; }
        public long? SqlKey { get; private set; }
        public bool DeletionPending { get; set; }

        public bool SavedRemote
        {
            get { return ObjectId != null && ObjectId.Exists(); }
        }

        // ====================
        // ABSTRACT METHODS
        // ====================

        /// <summary>
        /// Evaluates the user's competency with the language pair described by this learning profile, based on the encounter history with all 
        /// encountered translation pairs.
        /// </summary>
        /// <returns>
        /// A value that indicates the user's overall language competency.
        /// </returns>
        public abstract float EvaluateCompetency();


        /// <summary>
        /// Constructs an empty encounter history.  This is overriden by subclasses to ensure the appropriate encounter history subclass
        /// is used.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to build the empty encounter history for.</param>
        /// <returns>
        /// An empty encounter history.
        /// </returns>
        public abstract EncounterHistory BuildEmptyHistory(ParseObjectId pairId);

        /// <inheritdoc/>
        public abstract ISqlWrapper<LearnProfile> Wrap();

        /// <inheritdoc/>
        public abstract string SqlTableName { get; }
        
        /// <inheritdoc/>
        public abstract string SqlUniqueColumnName { get; }
        
        /// <inheritdoc/>
        public abstract object SqlUniqueColumnValue { get; }
        
        /// <summary>
        /// Builds a basic <see cref="PushParams{LearnProfile}"/> object out of this learning profile.
        /// </summary>
        /// <returns>
        /// The constructed push parameters object.
        /// </returns>
        public abstract PushParams<LearnProfile> GetPushParams();

        // ====================
        // CONSTRUCTORS
        // ====================

        protected LearnProfile(ParseObjectId objectId, ParseObjectId userId, Language sourceLang, Language targetLang, IEnumerable<EncounterHistory> pairs,
                               DateTime updatedAt)
        {
            ObjectId = objectId;
            UserId = userId;
            SourceLang = sourceLang;
            TargetLang = targetLang;
            UpdatedAt = updatedAt;
            History = HistoryCollection.Build(BuildEmptyHistory);
            foreach (EncounterHistory history in pairs)
                History.MergeHistory(history);
        }
        protected LearnProfile(string objectId, string userId, string sourceLang, string targetLang, IEnumerable<EncounterHistory> pairs,
                               DateTime updatedAt)
            : this(ParseObjectId.Of(objectId), ParseObjectId.Of(userId), 
                   LanguageUtils.Parse(sourceLang), LanguageUtils.Parse(targetLang), pairs, updatedAt)
        {
        }



        // ====================
        // METHODS (MAY BE OVERRIDEN BY SUBCLASSES)
        // ====================

        public LearnProfile SetSqlKey(long val)
        {
            if (SqlKey != null)
                throw new InvalidOperationException(string.Format("[{0}] SQL key has already been set.",
                                                                  this.GetType().Name));

            SqlKey = val;
            return this;
        }


        // ====================
        // OVERRIDES/IMPLEMENTS
        // ====================

        /// <inheritdoc/>
        /// <remarks>
        /// Example structure:
        /// <code>
        /// {
        ///   "objectId": "string",  // The learning profile's unique ID
        ///   "userId": "string", // The user's unique ID
        ///   "sourceLang": "string", // Language code of the source language
        ///   "targetLang": "string", // Language code of the target language
        ///   "info": {
        ///       // This object will vary depending on the implementation of 
        ///       // the scheduler; the server will store whatever is here
        ///       // without checking the contents for a particular structure.
        ///       // The following is just an example. 
        ///     "history": {
        ///       // Object that results from HistoryCollection.toJSON()       
        ///     },
        ///     "competency": 0
        ///   }
        /// }
        /// 
        /// </code>
        /// </remarks>
        public virtual JSONObject ToJSON()
        {
            JSONObject obj = new JSONObject(JSONObject.Type.OBJECT);

            obj.AddField(FIELD_OBJECT_ID, ObjectId.ToString());
            obj.AddField(FIELD_USER_ID, UserId.ToString());
            obj.AddField(FIELD_SOURCE_LANG, SourceLang.Stringify());
            obj.AddField(FIELD_TARGET_LANG, TargetLang.Stringify());

            JSONObject info = new JSONObject(JSONObject.Type.OBJECT);
            info.AddField(FIELD_INFO_COMPETENCY, EvaluateCompetency());
            
            info.AddField(FIELD_INFO_HISTORY, History.ToJSON());

            obj.AddField(FIELD_INFO, info);
            

            return obj;
        }
        
        

        /// <inheritdoc/>
        public ParseObjectId GetId()
        {
            return ObjectId;
        }
        
        /// <inheritdoc/>
        public DateTime GetUpdatedAt()
        {
            return UpdatedAt;
        }
        
        /// <inheritdoc/>
        public long? GetAlternateId()
        {
            return SqlKey;
        }
        
        /// <inheritdoc/>
        public void SetObjectId(ParseObjectId id)
        {
            if (ObjectId == null || !ObjectId.Exists())
                ObjectId = id;
            else
                throw new InvalidOperationException(string.Format("[{0}] Cannot change Parse object ID unless ID is empty.",
                                                                  this.GetType().FullName));
        }
        
        /// <inheritdoc/>
        public void SetUpdatedAt(DateTime timestamp)
        {
            UpdatedAt = timestamp;
        }
    }

}

