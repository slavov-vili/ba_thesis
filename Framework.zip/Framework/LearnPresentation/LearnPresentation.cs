﻿using System.Collections;
using System.Collections.Generic;

namespace Cabuu.Coach
{
    // ReSharper disable once ClassWithVirtualMembersNeverInherited.Global
    public class LearnPresentation : IJsonable
    {
        // CONSTANTS
        protected const string FIELD_PAIR_ID = "pairId";
        protected const string FIELD_TYPE = "type";
        protected const string FIELD_INFO = "info";

        public const string INFO_ANSWER_OPTIONS = "answerOptions";
        public const string INFO_PAIR_LIST = "pairList";

        protected static readonly string[] FIELDS =
        {
            FIELD_PAIR_ID, FIELD_TYPE
        };

        // MEMBERS
        public readonly ParseObjectId PairId;
        public readonly EncounterType Type;
        public readonly Dictionary<string, object> Info = new Dictionary<string, object>();

        // CONSTRUCTORS

        protected LearnPresentation(ParseObjectId pairId, EncounterType type)
        {
            PairId = pairId;
            Type = type;
        }
        protected LearnPresentation(string pairId, EncounterType type)
            : this(ParseObjectId.Of(pairId), type)
        {
        }


        // STATIC CONSTRUCTORS

        /// <summary>
        /// Builds a new <see cref="LearnPresentation"/> with the given translation pair object ID and encounter type.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to present.</param>
        /// <param name="type">Type of presentation.</param>
        /// <returns>
        /// A newly constructed <see cref="LearnPresentation"/> object.
        /// </returns>
        public static LearnPresentation Build(ParseObjectId pairId, EncounterType type)
        {
            return new LearnPresentation(pairId, type);
        }

        /// <summary>
        /// Builds a new <see cref="LearnPresentation"/> with the given translation pair object ID and encounter type.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to present.</param>
        /// <param name="type">Type of presentation.</param>
        /// <returns>
        /// A newly constructed <see cref="LearnPresentation"/> object.
        /// </returns>
        public static LearnPresentation Build(string pairId, EncounterType type)
        {
            return Build(ParseObjectId.Of(pairId), type);
        }

        /// <summary>
        /// Builds a new <see cref="LearnPresentation"/> from the given JSON object.
        /// If the JSON could not be successfully parsed, throws a <see cref="JSONException"/>.
        /// </summary>
        /// <param name="obj">The JSON object to parse for learn presentation info.</param>
        /// <returns>
        /// A newly constructed <see cref="LearnPresentation"/> object.
        /// </returns>
        public static LearnPresentation FromJSON(JSONObject obj)
        {
            if (obj == null || !obj.IsObject || !obj.HasFields(FIELDS))
                throw JSONUtils.GenericParsingError(obj, typeof(LearnPresentation));

            return Build(obj.GetParseObjectId(FIELD_PAIR_ID),
                         EnumParser<EncounterType>.Parse(obj.GetString(FIELD_TYPE)));
        }
        
        // CHAIN CONSTRUCTORS

        public virtual LearnPresentation AddInfo(string key, object val)
        {
            if (!Info.ContainsKey(key))
                Info.Add(key, val);
            else
                Info[key] = val;
            return this;
        }
        
        // METHODS

        public virtual T GetInfoOrNull<T>(string key) where T : class
        {
            if (key == null || !Info.ContainsKey(key) || !(Info[key] is T))
                return null;

            return (T) Info[key];
        }

        // OVERRIDES/IMPLEMENTS

        /// <inheritdoc/>
        /// <remarks>
        /// Example structure:
        /// <code>
        /// {
        ///   "pairId": "string", // The pair's unique ID
        ///   "type": "string", // The exercise type
        /// }
        /// 
        /// </code>
        /// </remarks>
        public virtual JSONObject ToJSON()
        {
            JSONObject obj = new JSONObject(JSONObject.Type.OBJECT);

            obj.AddField(FIELD_PAIR_ID, PairId.Id);
            obj.AddField(FIELD_TYPE, Type.ToString());
            obj.AddField(FIELD_INFO, GetInfoJSON());

            return obj;
        }

        protected virtual JSONObject GetInfoJSON()
        {
            JSONObject obj = new JSONObject(JSONObject.Type.OBJECT);
            foreach (var kvp in Info)
            {
                if (kvp.Key == null || kvp.Value == null)
                    continue;
                
                obj.AddField(kvp.Key, GetInfoFieldJSON(kvp.Value));
            }

            return obj;
        }

        private static JSONObject GetInfoFieldJSON(object val)
        {
            if (val == null)
                return new JSONObject(JSONObject.Type.NULL);
            
            if (val is IJsonable)
                return ((IJsonable) val).ToJSON();

            if (val is JSONObject)
                return (JSONObject) val;

            if (val is IEnumerable)
            {
                JSONObject arr = new JSONObject(JSONObject.Type.ARRAY);
                foreach (var elem in ((IEnumerable) val))
                    arr.Add(GetInfoFieldJSON(elem));
                return arr;
            }

            return new JSONObject(JSONObject.Type.STRING) {str = val.ToString()};
        }
    }
}