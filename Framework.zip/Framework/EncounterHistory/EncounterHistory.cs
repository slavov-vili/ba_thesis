﻿using System.Collections.Generic;

namespace Cabuu.Coach
{

    public abstract class EncounterHistory : IJsonable
    {
        public static readonly ComparisonComparer<LearnEncounter> ENCOUNTER_COMPARER = 
            new ComparisonComparer<LearnEncounter>((x, y) => x.Timestamp.CompareTo(y.Timestamp));

        // CONSTANTS
        protected const string FIELD_PAIR_ID = "pairId";
        protected const string FIELD_ENCOUNTERS = "encounters";
        protected const string FIELD_COMPETENCY = "competency";
        protected const string FIELD_NUM_ENCOUNTERS = "numEncounters";

        protected static readonly string[] FIELDS = {
            FIELD_PAIR_ID, FIELD_COMPETENCY, FIELD_ENCOUNTERS, FIELD_NUM_ENCOUNTERS
        };

        // MEMBERS
        public readonly ParseObjectId PairId;

        protected readonly List<LearnEncounter> Encounters = new List<LearnEncounter>();

        // ====================
        // ABSTRACT METHODS
        // ====================

        /// <summary>
        /// Evaluates the user's competency with the translation pair associated with this encounter history based on all encounters with the pair.
        /// </summary>
        /// <returns>
        /// A value between 0 and 1, inclusive, that represents the competency level of the user for this pair.
        /// </returns>
        public abstract float GetCompetency();

        /// <summary>
        /// Calculates an individual competency value to attribute to a single encounter.
        /// </summary>
        /// <param name="encounter">The encounter to evaluate for.</param>
        /// <returns>
        /// A value between 0 and 1, inclusive, that represents the user's competency with the pair in the given encounter.
        /// </returns>
        protected abstract float GetEncounterValue(LearnEncounter encounter);
        


        // ====================
        // CONSTRUCTORS
        // ====================
        
        protected EncounterHistory(ParseObjectId pairId)
        {
            PairId = pairId;
        }

        protected EncounterHistory(string pairId) : this(ParseObjectId.Of(pairId))
        {
        }

        protected EncounterHistory(ParseObjectId pairId, IEnumerable<LearnEncounter> encounters) : this(pairId)
        {
            foreach (LearnEncounter encounter in encounters)
                AddEncounter(encounter);
        }

        protected EncounterHistory(string pairId, IEnumerable<LearnEncounter> encounters) : this(ParseObjectId.Of(pairId), encounters)
        {
        }


        // ====================
        // METHODS (MAY BE OVERRIDEN BY SUBCLASSES)
        // ====================

        /// <summary>
        /// Returns the list of encounters as a read-only collection, in order to avoid accidental tampering with the list that might
        /// result in improper ordering of encounters.
        /// </summary>
        /// <returns>
        /// A read-only list of encounters in this encounter history, ordered chronologically.
        /// </returns>
        public virtual IEnumerable<LearnEncounter> GetEncounters()
        {
            return Encounters.AsReadOnly();
        }

        /// <summary>
        /// Adds the given encounter to the encounter history.
        /// </summary>
        /// <param name="encounter">The encounter to add.</param>
        public virtual void AddEncounter(LearnEncounter encounter)
        {
            if (!encounter.PairId.Equals(PairId))
            {
                //Debug.Log("[EncounterHistory] WARNING: Pair ID of learn encounter does not match pair ID of encounter history.");
                return;
            }
            int index = Encounters.BinarySearch(encounter, ENCOUNTER_COMPARER);
            if (index < 0) index = -(index + 1);
            Encounters.Insert(index, encounter);
        }



        /// <summary>
        /// Adds the given encounters to the encounter history.
        /// </summary>
        /// <param name="encounters">The encounters to add.</param>
        public virtual void AddEncounters(IEnumerable<LearnEncounter> encounters)
        {
            foreach (LearnEncounter encounter in encounters)
                AddEncounter(encounter);
        }



        /// <summary>
        /// Adds all encounters in the given encounter history to this encounter history.
        /// </summary>
        /// <param name="history">The encounter history to merge.</param>
        public virtual void MergeHistory(EncounterHistory history)
        {
            // TODO:  Can be made more efficient since the given history will have ordered encounters already, but this is simpler for now
            AddEncounters(history.Encounters);
        }



        /// <summary>
        /// Utility method that sorts all encounters chronologically.
        /// </summary>
        protected virtual void SortEncounters()
        {
            Encounters.Sort(ENCOUNTER_COMPARER);
        }



        ///
        /// <summary>
        /// Returns the number of encounters in the encounter history.  This may simply
        /// return encounters.size() for subclasses that use a full encounter history,
        /// or some cached value for subclasses that use an encounter summary.
        /// </summary>
        /// 
        /// <returns>
        /// The number of encounters in this encounter history.
        /// </returns>
        ///
        public virtual int GetNumOfEncounters()
        {
            return Encounters.Count;
        }






        // ====================
        // OVERRIDES/IMPLEMENTS
        // ====================

        /// <inheritdoc/>
        /// <remarks>
        /// Example structure:
        /// <code>
        /// {
        ///   "pairId": "string",  // The pair's unique ID
        ///   "encounters": [
        ///       // Objects that result from LearnEncounter.toJSON()
        ///   ],
        ///   "competency": 0.0, // Competency evaluation
        ///   "numEncounters": 0 // Number of encounters in history
        /// }
        /// 
        /// </code>
        /// </remarks>
        public virtual JSONObject ToJSON()
        {
            JSONObject obj = new JSONObject(JSONObject.Type.OBJECT);

            obj.AddField(FIELD_PAIR_ID, PairId.Id);
            obj.AddField(FIELD_COMPETENCY, GetCompetency());
            obj.AddField(FIELD_NUM_ENCOUNTERS, GetNumOfEncounters());

            JSONObject arr = new JSONObject(JSONObject.Type.ARRAY);
            foreach (LearnEncounter encounter in Encounters)
                arr.Add(encounter.ToJSON());
            obj.AddField(FIELD_ENCOUNTERS, arr);

            return obj;
        }
    }
    
}