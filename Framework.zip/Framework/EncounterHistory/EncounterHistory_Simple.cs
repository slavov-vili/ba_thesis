﻿using System.Collections.Generic;
using System.Linq;

namespace Cabuu.Coach
{
    /// <summary>
    /// A dumb, placeholder implementation of <see cref="EncounterHistory"/> that evaluates competency by
    /// simply taking an average of encounter values that are assigned to the results of each component
    /// learning encounter in the history.
    /// </summary>
    public sealed class EncounterHistory_Simple : EncounterHistory
    {
        // MEMBERS
        private float? cachedCompetency = null;

        // ====================
        // CONSTRUCTORS
        // ====================

        private EncounterHistory_Simple(ParseObjectId pairId) : base(pairId)
        {
        }
        private EncounterHistory_Simple(string pairId) : base(pairId)
        {
        }
        private EncounterHistory_Simple(ParseObjectId pairId, IEnumerable<LearnEncounter> encounters) : base(pairId, encounters)
        {
        }
        private EncounterHistory_Simple(string pairId, IEnumerable<LearnEncounter> encounters) : base(pairId, encounters)
        {
        }


        // ====================
        // STATIC CONSTRUCTORS
        // ====================

        /// <summary>
        /// Constructs a new encounter history for the given translation pair with the given encounters.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to build this history for.</param>
        /// <param name="encounters">Encounters to initialize encounter history with.</param>
        /// <returns>
        /// The newly constructed <see cref="EncounterHistory"/> object.
        /// </returns>
        public static EncounterHistory Build(ParseObjectId pairId, IEnumerable<LearnEncounter> encounters)
        {
            return new EncounterHistory_Simple(pairId, encounters);
        }

        /// <summary>
        /// Constructs a new encounter history for the given translation pair with the given encounters.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to build this history for.</param>
        /// <param name="encounters">Encounters to initialize encounter history with.</param>
        /// <returns>
        /// The newly constructed <see cref="EncounterHistory"/> object.
        /// </returns>
        public static EncounterHistory Build(string pairId, IEnumerable<LearnEncounter> encounters)
        {
            return Build(ParseObjectId.Of(pairId), encounters);
        }

        /// <summary>
        /// Constructs a new encounter history for the given translation pair with no encounters.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to build this history for.</param>
        /// <returns>
        /// The newly constructed <see cref="EncounterHistory"/> object.
        /// </returns>
        public static EncounterHistory Build(ParseObjectId pairId)
        {
            return new EncounterHistory_Simple(pairId);
        }

        /// <summary>
        /// Constructs a new encounter history for the given translation pair with no encounters.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to build this history for.</param>
        /// <returns>
        /// The newly constructed <see cref="EncounterHistory"/> object.
        /// </returns>
        public static EncounterHistory Build(string pairId)
        {
            return Build(ParseObjectId.Of(pairId));
        }

        /// <summary>
        /// Constructs a new simple encounter history object using the values contained in the given 
        /// encounter history JSON object.
        /// If the JSON could not be successfully parsed, throws a <see cref="JSONException"/>.
        /// </summary>
        /// <param name="obj">JSON object in the form as created by <see cref="EncounterHistory.ToJSON"/></param>
        /// <returns>
        /// The newly constructed <see cref="EncounterHistory_Simple"/> object.
        /// </returns>
        public static EncounterHistory FromJSON(JSONObject obj)
        {
            if (obj == null || !obj.IsObject || !obj.HasFields(FIELDS))
                throw JSONUtils.GenericParsingError(obj, typeof(EncounterHistory_Simple));

            return Build(obj.GetParseObjectId(FIELD_PAIR_ID),
                         obj.GetJSONArray(FIELD_ENCOUNTERS).list
                                  .Select(LearnEncounter_Simple.FromJSON)
                                  .Where(x => x != null));
        }




        // ====================
        // OVERRIDES/IMPLEMENTS
        // ====================


        /// <inheritdoc/>
        /// <remarks>
        /// For <see cref="EncounterHistory_Simple"/>, un-caches compentency value, forcing it to
        /// need to be recalculated upon calling <see cref="GetCompetency"/> again.
        /// </remarks>
        public override void AddEncounter(LearnEncounter encounter)
        {
            base.AddEncounter(encounter);
            cachedCompetency = null;
        }

        /// <inheritdoc/>
        /// <remarks>
        /// For <see cref="EncounterHistory_Simple"/>, a simple average is taken for all encounter values.
        /// </remarks>
        public override float GetCompetency()
        {
            if (cachedCompetency == null)
                cachedCompetency = Encounters.Select(GetEncounterValue).Where(x => x >= 0).Average();

            return cachedCompetency.Value;
        }

        /// <inheritdoc/>
        protected override float GetEncounterValue(LearnEncounter encounter)
        {
            switch (encounter.Result)
            {
                case EncounterResult.CORRECT:
                    return 1f;
                case EncounterResult.INCORRECT:
                case EncounterResult.SKIPPED:
                    return 0f;
                case EncounterResult.PARTIAL:
                    return 0.5f;
                default:
                    return -1f;
            }
        }
    }
}