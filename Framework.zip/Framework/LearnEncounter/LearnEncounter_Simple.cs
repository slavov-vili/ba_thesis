﻿using System;

namespace Cabuu.Coach
{
    public sealed class LearnEncounter_Simple : LearnEncounter
    {
        // ====================
        // CONSTRUCTORS
        // ====================

        private LearnEncounter_Simple(string pairId, EncounterType type, EncounterResult result, DateTime timestamp) : base(pairId, type, result, timestamp)
        {
        }
        private LearnEncounter_Simple(ParseObjectId pairId, EncounterType type, EncounterResult result, DateTime timestamp) : base(pairId, type, result, timestamp)
        {
        }

        // ====================
        // STATIC CONSTRUCTORS
        // ====================

        /// <summary>
        /// Constructs a new simple learning encounter object, using the given values.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair presented in this learning encounter.</param>
        /// <param name="type">The presentation type of the learning encounter.</param>
        /// <param name="result">The result of the learning encounter.</param>
        /// <param name="timestamp">Timestamp of when the learning encounter occurred.</param>
        /// <returns>
        /// The newly constructed <see cref="LearnEncounter_Simple"/> object.
        /// </returns>
        public static LearnEncounter Build(ParseObjectId pairId, EncounterType type, EncounterResult result, DateTime timestamp)
        {
            return new LearnEncounter_Simple(pairId, type, result, timestamp);
        }

        /// <summary>
        /// Constructs a new simple learning encounter object, using the given values.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair presented in this learning encounter.</param>
        /// <param name="type">The presentation type of the learning encounter.</param>
        /// <param name="result">The result of the learning encounter.</param>
        /// <param name="timestamp">Timestamp of when the learning encounter occurred.</param>
        /// <returns>
        /// The newly constructed <see cref="LearnEncounter_Simple"/> object.
        /// </returns>
        public static LearnEncounter Build(string pairId, EncounterType type, EncounterResult result, DateTime timestamp)
        {
            return Build(ParseObjectId.Of(pairId), type, result, timestamp);
        }

        /// <summary>
        /// Constructs a new simple learning encounter object using the values contained in the given learning encounter JSON object.
        /// If the JSON could not be successfully parsed, throws a <see cref="JSONException"/>.
        /// </summary>
        /// <param name="obj">JSON object in the form as created by <see cref="LearnEncounter.ToJSON"/></param>
        /// <returns>
        /// The newly constructed <see cref="LearnEncounter_Simple"/> object.
        /// </returns>
        public static LearnEncounter FromJSON(JSONObject obj)
        {
            if (obj == null || !obj.IsObject || !obj.HasFields(FIELDS))
                throw JSONUtils.GenericParsingError(obj, typeof(LearnEncounter_Simple));

            return Build(obj.GetParseObjectId(FIELD_PAIR_ID),
                         EnumParser<EncounterType>.Parse(obj.GetString(FIELD_TYPE)),
                         EnumParser<EncounterResult>.Parse(obj.GetString(FIELD_RESULT)),
                         obj.GetTimestamp(FIELD_TIME));
        }
    }
}