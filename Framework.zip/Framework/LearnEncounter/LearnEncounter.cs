﻿using System;

namespace Cabuu.Coach
{
    public abstract class LearnEncounter : IJsonable
    {
        // CONSTANTS
        protected const string FIELD_TYPE = "type";
        protected const string FIELD_PAIR_ID = "pairId";
        protected const string FIELD_RESULT = "result";
        protected const string FIELD_TIME = "timestamp";
        protected static readonly string[] FIELDS = {
            FIELD_TYPE, FIELD_PAIR_ID, FIELD_RESULT, FIELD_TIME
        };

        // MEMBERS
        public readonly ParseObjectId PairId;
        public readonly EncounterType Type;
        public readonly EncounterResult Result;
        public readonly DateTime Timestamp;


        // ====================
        // CONSTRUCTORS
        // ====================

        protected LearnEncounter(string pairId, EncounterType type, EncounterResult result, DateTime timestamp)
            : this(ParseObjectId.Of(pairId), type, result, timestamp)
        {
        }
        protected LearnEncounter(ParseObjectId pairId, EncounterType type, EncounterResult result, DateTime timestamp)
        {
            PairId = pairId;
            Type = type;
            Result = result;
            Timestamp = timestamp;
        }


        // ====================
        // ABSTRACT METHODS
        // ====================

        /// <inheritdoc/>
        /// <remarks>
        /// Example structure:
        /// <code>
        /// {
        ///   "pairId": "string", // The pair's unique ID
        ///   "exerciseType": "string", // The exercise type
        ///   "result": "string", // The encounter result
        ///   "timestamp": "string"  // String representation of the encounter time
        /// }
        /// 
        /// </code>
        /// </remarks>
        public virtual JSONObject ToJSON()
        {
            JSONObject obj = new JSONObject(JSONObject.Type.OBJECT);

            obj.AddField(FIELD_PAIR_ID, PairId.Id);
            obj.AddField(FIELD_TYPE, Type.ToString());
            obj.AddField(FIELD_RESULT, Result.ToString());
            obj.AddField(FIELD_TIME, Timestamp.Stringify());

            return obj;
        }
    }
}