﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Cabuu.Coach
{
    public class LearnEvent_Simple : LearnEvent
    {
        // ====================
        // CONSTRUCTORS
        // ====================


        private LearnEvent_Simple(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<ParseObjectId> pairIds,
                                  int position, IEnumerable<LearnPresentation> presentations, HistoryCollection history)
            : base(id, type, date, status, profile, pairIds, position, presentations, history)
        {
        }
        private LearnEvent_Simple(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<string> pairIds,
                                  int position, IEnumerable<LearnPresentation> presentations, HistoryCollection history)
            : base(id, type, date, status, profile, pairIds, position, presentations, history)
        {
        }
        private LearnEvent_Simple(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<ParseObjectId> pairIds)
            : base(id, type, date, status, profile, pairIds)
        {
        }
        private LearnEvent_Simple(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<string> pairIds)
            : base(id, type, date, status, profile, pairIds)
        {
        }


        // ====================
        // STATIC CONSTRUCTORS
        // ====================

        /// <summary>
        /// Constructs a new learning event using the provided values.
        /// </summary>
        /// <param name="id">The event ID of the new learning event.</param>
        /// <param name="type">The type of learning event.</param>
        /// <param name="date">The date the learning event is supposed to occur on.</param>
        /// <param name="status">The current status of the learning event.</param>
        /// <param name="profile">The learning profile of the user the event is scheduled for.</param>
        /// <param name="pairIds">A collection of translation pair Parse object IDs to include in the event's presentations.</param>
        /// <param name="position">The current presentation position in the learning event.</param>
        /// <param name="presentations">A collection of pre-generated future learning presentations to add to this event.</param>
        /// <param name="history">A history of all encounters that have already occurred in this event.  If null, creates a new
        /// empty history collection.</param>
        /// <returns>
        /// The newly constructed <see cref="LearnScheduler_Simple"/> object.
        /// </returns>
        public static LearnEvent Build(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<ParseObjectId> pairIds,
                                       int position, IEnumerable<LearnPresentation> presentations, HistoryCollection history)
        {
            return new LearnEvent_Simple(id, type, date, status, profile, pairIds, position, presentations, history);
        }

        /// <summary>
        /// Constructs a new learning event using the provided values.
        /// </summary>
        /// <param name="id">The event ID of the new learning event.</param>
        /// <param name="type">The type of learning event.</param>
        /// <param name="date">The date the learning event is supposed to occur on.</param>
        /// <param name="status">The current status of the learning event.</param>
        /// <param name="profile">The learning profile of the user the event is scheduled for.</param>
        /// <param name="pairIds">A collection of translation pair Parse object IDs to include in the event's presentations.</param>
        /// <param name="position">The current presentation position in the learning event.</param>
        /// <param name="presentations">A collection of pre-generated future learning presentations to add to this event.</param>
        /// <param name="history">A history of all encounters that have already occurred in this event.  If null, creates a new
        /// empty history collection.</param>
        /// <returns>
        /// The newly constructed <see cref="LearnScheduler_Simple"/> object.
        /// </returns>
        public static LearnEvent Build(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<string> pairIds,
                                       int position, IEnumerable<LearnPresentation> presentations, HistoryCollection history)
        {
            return Build(id, type, date, status, profile, pairIds.Select(ParseObjectId.Of), position, presentations, history);
        }

        /// <summary>
        /// Constructs a new learning event using the provided values.
        /// </summary>
        /// <param name="id">The event ID of the new learning event.</param>
        /// <param name="type">The type of learning event.</param>
        /// <param name="date">The date the learning event is supposed to occur on.</param>
        /// <param name="status">The current status of the learning event.</param>
        /// <param name="profile">The learning profile of the user the event is scheduled for.</param>
        /// <param name="pairIds">A collection of translation pair Parse object IDs to include in the event's presentations.</param>
        /// <returns>
        /// The newly constructed <see cref="LearnScheduler_Simple"/> object.
        /// </returns>
        public static LearnEvent Build(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<ParseObjectId> pairIds)
        {
            return new LearnEvent_Simple(id, type, date, status, profile, pairIds);
        }

        /// <summary>
        /// Constructs a new learning event using the provided values.
        /// </summary>
        /// <param name="id">The event ID of the new learning event.</param>
        /// <param name="type">The type of learning event.</param>
        /// <param name="date">The date the learning event is supposed to occur on.</param>
        /// <param name="status">The current status of the learning event.</param>
        /// <param name="profile">The learning profile of the user the event is scheduled for.</param>
        /// <param name="pairIds">A collection of translation pair Parse object IDs to include in the event's presentations.</param>
        /// <returns>
        /// The newly constructed <see cref="LearnScheduler_Simple"/> object.
        /// </returns>
        public static LearnEvent Build(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<string> pairIds)
        {
            return Build(id, type, date, status, profile, pairIds.Select(ParseObjectId.Of));
        }

        /// <summary>
        /// Constructs a new learning event using the values contained in the given learning event JSON object.
        /// </summary>
        /// <param name="profile">The learning profile of the user the event is scheduled for.</param>
        /// <param name="obj">JSON object in the form as created by <see cref="LearnEvent.ToJSON"/></param>
        /// <returns>
        /// The newly constructed <see cref="LearnEvent_Simple"/> object.
        /// </returns>
        public static LearnEvent FromJSON(LearnProfile profile, JSONObject obj)
        {
            if (obj == null || !obj.IsObject || !obj.HasFields(FIELDS))
                throw JSONUtils.GenericParsingError(obj, typeof(LearnEvent_Simple));

            JSONObject historyObj = obj.GetJSONObject(FIELD_HISTORY);
            HistoryCollection hist = HistoryCollection.FromJSON(EncounterHistory_Simple.Build,
                                                                EncounterHistory_Simple.FromJSON,
                                                                historyObj);

            IEnumerable<LearnPresentation> presentations = obj.GetJSONArray(FIELD_PRESENTATIONS)
                                                              .list.Select(LearnPresentation.FromJSON);

            return Build(EventId.Of(obj.GetString(FIELD_ID)),
                         EnumParser<EventType>.Parse(obj.GetString(FIELD_TYPE)),
                         obj.GetTimestamp(FIELD_DATE),
                         EnumParser<EventStatus>.Parse(obj.GetString(FIELD_STATUS)),
                         profile,
                         GetPairsFromPresentations(presentations),
                         obj.GetInt(FIELD_POSITION),
                         presentations,
                         hist);
        }


        // ====================
        // OVERRIDES/IMPLEMENTS
        // ====================

        /// <inheritdoc />
        /// <remarks>
        /// For <see cref="LearnEvent_Simple"/>, does NOT trigger recalculation.
        /// </remarks>
        public override LearnPresentation Next()
        {
            Position++;
            return GetCurrentPresentation();
        }

        /// <inheritdoc />
        /// <remarks>
        /// For <see cref="LearnEvent_Simple"/>, does NOT trigger recalculation.
        /// </remarks>
        public override LearnPresentation PeekNext()
        {
            return GetPresentation(Position + 1);
        }

        /// <inheritdoc />
        /// <remarks>
        /// For <see cref="LearnEvent_Simple" />, simply presents all translation pairs that have not yet been presented.
        /// </remarks>
        public override LearnEvent RecalculateOrdering(int pos)
        {
            presentations.RemoveRange(pos, presentations.Count - pos);
            HashSet<ParseObjectId> presented = new HashSet<ParseObjectId>(ChronoEventHistory.Select(x => x.PairId));
            IEnumerable<ParseObjectId> remaining = pairs.Where(x => !presented.Contains(x));

            EncounterType et;
            switch (Type)
            {
                case EventType.LEARN:
                    et = EncounterType.Study_Default;
                    break;
                case EventType.EXAM:
                case EventType.TEST:
                    et = EncounterType.Test_LetterSalad;
                    break;
                default:
                    et = EncounterType.Test_LetterSalad;
                    break;
            }

            foreach (ParseObjectId id in remaining)
                presentations.Add(LearnPresentation.Build(id, et));

            return this;
        }

        /// <inheritdoc/>
        /// <remarks>
        /// For <see cref="LearnEvent_Simple"/>, returns <see cref="EncounterHistory_Simple"/>.
        /// </remarks>
        public override EncounterHistory BuildEmptyHistory(ParseObjectId pairId)
        {
            return EncounterHistory_Simple.Build(pairId);
        }

        /// <inheritdoc/>
        /// <remarks>
        /// For <see cref="LearnEvent_Simple"/>, adds a <see cref="LearnEncounter_Simple"/>.
        /// </remarks>
        public override void AddEncounter(LearnPresentation presentation, EncounterResult result)
        {
            var enc = LearnEncounter_Simple.Build(presentation.PairId,
                                                  presentation.Type,
                                                  result,
                                                  DateTime.Now);
            AddEncounter(enc);
        }
    }
}