﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Cabuu.Coach
{
    /// <summary>
    /// This class handles everything to do with a particular learning event.  Each learning event is assigned a unique identifier
    /// for referring to by the scheduler.  The learning event is assigned items to present, and is responsible for determining
    /// how these items should be presented in terms of ordering, type, and frequency.  The learning event also has a <see cref="Status"/>
    /// property, but this is <b>not</b> automatically updated with the state of the learning event; this status must be manually
    /// updated by setting the member directly, or by calling <see cref="AutoUpdateStatus"/>.
    /// </summary>
    public abstract class LearnEvent : IJsonable
    {
        // CONSTANTS
        protected const string FIELD_PRESENTATIONS = "presentations";
        protected const string FIELD_POSITION = "position";
        protected const string FIELD_ID = "id";
        protected const string FIELD_TYPE = "type";
        protected const string FIELD_DATE = "date";
        protected const string FIELD_STATUS = "status";
        protected const string FIELD_HISTORY = "history";

        protected static readonly string[] FIELDS =
        {
            FIELD_PRESENTATIONS, FIELD_POSITION, FIELD_ID, FIELD_TYPE, FIELD_DATE, FIELD_STATUS, FIELD_HISTORY
        };

        // MEMBERS
        public readonly EventId Id;
        public readonly EventType Type;
        public readonly DateTime Date;
        public EventStatus Status { get; set; }
        protected readonly List<LearnPresentation> presentations = new List<LearnPresentation>();
        protected readonly HashSet<ParseObjectId> pairs;
        protected readonly LearnProfile profile;
        public int Position { get; protected set; }
        public readonly HistoryCollection EventHistory;
        protected readonly List<LearnEncounter> ChronoEventHistory = new List<LearnEncounter>();

        // ====================
        // ABSTRACT METHODS
        // ====================

        /// <summary>
        /// Recalculates the presentations to be made starting at the given ordering position.  This may shuffle existing presentations
        /// in a particular way, and also may add or remove presentations.  The particular recalculation implementation is determined
        /// by subclasses.
        /// </summary>
        /// <param name="position">The ordering position to start recalculating the ordering from.</param>
        /// <returns>
        /// Returns this learn event object in order to facilitate chaining.
        /// </returns>
        public abstract LearnEvent RecalculateOrdering(int position);

        /// <summary>
        /// Recalculates the presentations to made starting at the current ordering position. This may shuffle existing presentations
        /// in a particular way, and also may add or remove presentations.  The particular recalculation implementation is determined
        /// by subclasses.
        /// </summary>
        /// <returns>
        /// Returns this learn event object in order to facilitate chaining.
        /// </returns>
        public virtual LearnEvent RecalculateOrdering()
        {
            return RecalculateOrdering(Position);
        }

        /// <summary>
        /// Constructs an empty encounter history.  This is overriden by subclasses to ensure the appropriate encounter history subclass
        /// is used.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to build the empty encounter history for.</param>
        /// <returns>
        /// An empty encounter history.
        /// </returns>
        public abstract EncounterHistory BuildEmptyHistory(ParseObjectId pairId);

        /// <summary>
        /// Combines the given presentation with the result of that presentation to create a new
        /// <see cref="LearnEncounter"/> object that is added to the encounter history for this event.
        /// This is overridden by subclasses to generate this <see cref="LearnEncounter"/> as the subclass sees fit.
        /// </summary>
        /// <param name="presentation"></param>
        /// <param name="result"></param>
        public abstract void AddEncounter(LearnPresentation presentation, EncounterResult result);

        // ====================
        // CONSTRUCTORS
        // ====================

        protected LearnEvent(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<ParseObjectId> pairIds, 
                             int position, IEnumerable<LearnPresentation> presentations, HistoryCollection history)
        {
            Id = id;
            Type = type;
            Date = date;
            Status = status;

            this.pairs = new HashSet<ParseObjectId>(pairIds);

            this.profile = profile;
            this.Position = position;
            this.presentations.AddRange(presentations);
            this.EventHistory = history ?? HistoryCollection.Build(BuildEmptyHistory);

            foreach (EncounterHistory eh in EventHistory.GetAllEncounterHistories())
                ChronoEventHistory.AddRange(eh.GetEncounters());
            ChronoEventHistory.Sort((x, y) => x.Timestamp.CompareTo(y.Timestamp));
        }
        protected LearnEvent(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<string> pairIds,
                             int position, IEnumerable<LearnPresentation> presentations, HistoryCollection history)
            : this(id, type, date, status, profile, pairIds.Select(ParseObjectId.Of), position, presentations, history)
        { }
        protected LearnEvent(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<ParseObjectId> pairIds)
            : this(id, type, date, status, profile, pairIds, 0, new List<LearnPresentation>(), null)
        { }
        protected LearnEvent(EventId id, EventType type, DateTime date, EventStatus status, LearnProfile profile, IEnumerable<string> pairIds)
            : this(id, type, date, status, profile, pairIds.Select(ParseObjectId.Of), 0, new List<LearnPresentation>(), null)
        { }

        // ====================
        // METHODS (MAY BE OVERRIDDEN BY SUBCLASSES)
        // ====================

        /// <summary>
        /// Adds the given learning encounter to event's learning encounter history collection, as well as 
        /// adding the encounter to the chronological list of event encounters.  To only add the encounter
        /// to the history collection, call <see cref="HistoryCollection.AddEncounter"/> on 
        /// <see cref="EventHistory"/> directly.
        /// </summary>
        /// <param name="encounter">The learning encounter to add.</param>
        public virtual void AddEncounter(LearnEncounter encounter)
        {
            EventHistory.AddEncounter(encounter);
            EncounterHistory.ENCOUNTER_COMPARER.BinaryInsertion(encounter, ChronoEventHistory);
        }

        /// <summary>
        /// Retrieves the <see cref="LearnPresentation"/> that this learn event is current pointing at.
        /// If this learn event is finished, returns null.
        /// </summary>
        /// <returns>
        /// The currently pointed-at learn presentation, or null if the learn event is finished.
        /// </returns>
        public virtual LearnPresentation GetCurrentPresentation()
        {
            return GetPresentation(Position);
        }
        
        /// <summary>
        /// Retrieves the <see cref="LearnPresentation"/> that at the given ordering position.
        /// If this position is invalid, returns null.
        /// </summary>
        /// <param name="pos">The index position of the learn presentation to retrieve.</param>
        /// <returns>
        /// The learn presentation at the given index, or null if the index is invalid.
        /// </returns>
        public virtual LearnPresentation GetPresentation(int pos)
        {
            return pos >= 0 && pos < presentations.Count ? presentations[pos] : null;
        }

        /// <summary>
        /// Retrieves a read-only list of all <see cref="LearnPresentation"/>s in order of presentation.
        /// </summary>
        /// <returns>
        /// An ordered, read-only list of all learning presentations in this learning event.
        /// </returns>
        public virtual IEnumerable<LearnPresentation> GetAllPresentations()
        {
            return presentations.AsReadOnly();
        }

        
        /// <summary>
        /// Retrieves the total number of presentations in this event.
        /// </summary>
        /// <returns>
        /// The total number of presentations in this event.
        /// </returns>
        public virtual int GetPresentationCount()
        {
            return presentations.Count;
        }

        /// <summary>
        /// Retrieves the next <see cref="LearnPresentation"/> in the ordering, triggering a recalculation
        /// of the ordering (after the current ordering position), but not advancing the position counter 
        /// of this learn event.
        /// </summary>
        /// <returns>
        /// The next learn presentation in the ordering.
        /// </returns>
        public virtual LearnPresentation PeekNext()
        {
            RecalculateOrdering(Position + 1);
            return GetPresentation(Position + 1);
        }

        /// <summary>
        /// Retrieves the next <see cref="LearnPresentation"/> in the ordering, triggering a recalculation
        /// of the ordering, and advancing the position counter of this learn event.  This means
        /// that this <see cref="LearnEvent"/> will be in a different state after calling this
        /// method.
        /// </summary>
        /// <returns>
        /// The next learn presentation in the ordering.
        /// </returns>
        public virtual LearnPresentation Next()
        {
            Position++;
            RecalculateOrdering();
            return GetCurrentPresentation();
        }

        public virtual IEnumerable<LearnPresentation> Next(int count)
        {
            for (int i = Position; i < Position + count; i++)
                yield return GetPresentation(i);

            Position += count;
            RecalculateOrdering();
        }

        /// <summary>
        /// Indicates whether this event has already been started or if it still waiting to start.
        /// </summary>
        /// <returns>
        /// Returns true if this learn event has been started, false otherwise.
        /// </returns>
        public virtual bool IsStarted()
        {
            return Position >= 0;
        }

        /// <summary>
        /// Indicates whether this event has been completed, having reached the end of its presentation list.
        /// If this returns true, then <see cref="GetCurrentPresentation"/> will return null.
        /// </summary>
        /// <returns>
        /// Returns true if this learn event has been finished, false otherwise.
        /// </returns>
        public virtual bool IsFinished()
        {
            return Position >= presentations.Count;
        }

        /// <summary>
        /// Adds the given Parse object ID for a translation pair to this learn event for consideration
        /// when recalculating the ordering.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to add.</param>
        public virtual void AddPair(ParseObjectId pairId)
        {
            pairs.Add(pairId);
            EventHistory.AddTranslationPair(pairId);
        }

        /// <summary>
        /// Adds the given translation pair Parse object IDs to this learn event for consideration
        /// when recalculating the ordering.
        /// </summary>
        /// <param name="pairIds">Parse object IDs of the translation pairs to add.</param>
        public virtual void AddPairs(IEnumerable<ParseObjectId> pairIds)
        {
            foreach (ParseObjectId pairId in pairIds)
                AddPair(pairId);
        }

        /// <summary>
        /// Removes the given Parse object ID for a translation pair to this learn event,
        /// removing it from consideration when recalculating the ordering and erasing any previous
        /// encounters with the pair from the event history.
        /// </summary>
        /// <param name="pairId">Parse object ID of the translation pair to remove.</param>
        public virtual void RemovePair(ParseObjectId pairId)
        {
            pairs.Remove(pairId);
            EventHistory.RemoveTranslationPair(pairId);
        }

        /// <summary>
        /// Removes the given translation pair Parse object IDs from this learn event,
        /// removing them from consideration when recalculating the ordering and erasing any previous
        /// encounters with the pairs from the event history.
        /// </summary>
        /// <param name="pairIds">Parse object IDs of the translation pairs to remove.</param>
        public virtual void RemovePairs(IEnumerable<ParseObjectId> pairIds)
        {
            foreach (ParseObjectId pairId in pairIds)
                RemovePair(pairId);
        }

        /// <summary>
        /// Completely resets the list of translation pairs in this learn event to match
        /// the given translation pairs.  Also completely wipes the event history.  Use with
        /// caution.
        /// </summary>
        /// <param name="pairIds">Parse object IDs of translation pairs to repopulate this
        /// learn event with.</param>
        public virtual void SetPairs(IEnumerable<ParseObjectId> pairIds)
        {
            pairs.Clear();
            EventHistory.WipeCollection();
            foreach (ParseObjectId pairId in pairIds)
                AddPair(pairId);
        }

        /// <summary>
        /// Retrieves all translation pair Parse object IDs in this learn event.
        /// </summary>
        /// <returns>
        /// Parse object IDs of all translation pairs in this learn event.
        /// </returns>
        public virtual IEnumerable<ParseObjectId> GetTranslationPairIDs()
        {
            return pairs;
        }

        /// <summary>
        /// Updates the status of this learning event based based on its current state, and
        /// also returns the newly udpated status.
        /// Because the state of the learning event is normally not automatically updated as the state
        /// of the event changes, this must be called to force the update (this is so that unwanted
        /// changes to the state are not made, giving more control to external systems handling the
        /// learning event).
        /// </summary>
        /// <returns>
        /// The new status of this learn event.
        /// </returns>
        public virtual EventStatus AutoUpdateStatus()
        {
            if (IsFinished())
                Status = EventStatus.COMPLETE;
            else if (IsStarted())
                Status = EventStatus.INCOMPLETE;
            else if (DateUtils.IsAfterDay(DateTime.Now, Date))
                Status = EventStatus.MISSED;
            else
                Status = EventStatus.PENDING;

            return Status;
        }

        // ====================
        // STATIC METHODS
        // ====================

        /// <summary>
        /// Extracts all Parse object IDs represented in the given set of learn presentations.
        /// </summary>
        /// <param name="presentations">The learn presentations to extract Parse object IDs from.</param>
        /// <returns>
        /// A set of all Parse object IDs found in the given learn presentations.
        /// </returns>
        protected static IEnumerable<ParseObjectId> GetPairsFromPresentations(IEnumerable<LearnPresentation> presentations)
        {
            return new HashSet<ParseObjectId>(presentations.Select(x => x.PairId));
        }


        // ====================
        // OVERRIDES/IMPLEMENTS
        // ====================


        /// <inheritdoc/>
        /// <remarks>
        /// Example structure:
        /// <code>
        /// {
        ///   "id": "string",  // The event's unique identifier
        ///   "type": "string", // The event's type
        ///   "date": "string", // String representation of the event's date
        ///   "status": "string", // The event's current status
        ///   "history": {
        ///     // Object that results from HistoryCollection.toJSON()
        ///   },
        ///   "presentations": [
        ///       // Objects that result from LearnPresentation.toJSON()
        ///   ],
        ///   "position": 0 // Current position in the ordering
        /// }
        /// 
        /// </code>
        /// </remarks>
        public virtual JSONObject ToJSON()
        {
            JSONObject obj = new JSONObject(JSONObject.Type.OBJECT);

            obj.AddField(FIELD_ID, Id.Id);
            obj.AddField(FIELD_TYPE, Type.ToString());
            obj.AddField(FIELD_DATE, Date.Stringify());
            obj.AddField(FIELD_STATUS, Status.ToString());
            obj.AddField(FIELD_HISTORY, EventHistory.ToJSON());
            obj.AddField(FIELD_POSITION, Position);

            JSONObject arr = new JSONObject(JSONObject.Type.ARRAY);
            foreach (LearnPresentation lp in presentations)
                arr.Add(lp.ToJSON());

            obj.AddField(FIELD_PRESENTATIONS, arr);

            return obj;
        }
    }
}
