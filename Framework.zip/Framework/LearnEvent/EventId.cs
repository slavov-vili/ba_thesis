﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cabuu;

public class EventId : IComparable<EventId>
{
    // STATIC ELEMENTS
    private static readonly HashSet<string> TAKEN = new HashSet<string>();
    private const string CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
    private const int ID_LENGTH = 24;


    // MEMBERS
    public readonly string Id;


    // PRIVATE CONSTRUCTOR
    private EventId(string id)
    {
        Id = id == "" ? null : id;
        if (Id != null && !TAKEN.Contains(Id))
            TAKEN.Add(Id);
    }

    // STATIC CONSTRUCTORS

    /// <summary>
    /// Static constructor.  Builds a <see cref="EventId"/> from the given string.
    /// </summary>
    /// <param name="id">The event ID string to assign to the new object.</param>
    /// <returns>
    /// The newly constructed <see cref="EventId"/> object.
    /// </returns>
    public static EventId Of(string id)
    {
        return new EventId(id);
    }

    /// <summary>
    /// Static constructor.  Builds an empty <see cref="EventId"/>.
    /// This is equivalent to <code>EventId.Of(null)</code> and
    /// <code>EventId.Of("").</code>
    /// </summary>
    /// <returns>
    /// The newly constructed <see cref="EventId"/> object.
    /// </returns>
    public static EventId Empty()
    {
        return new EventId(null);
    }

    /// <summary>
    /// Static constructor.  Builds an <see cref="EventId"/> with a new, unique event ID.
    /// </summary>
    /// <returns>
    /// The newly constructed <see cref="EventId"/> object.
    /// </returns>
    public static EventId New()
    {
        return new EventId(BuildNewId());
    }


    // METHODS



    /// <summary>
    /// Indicates whether or not the event ID exists.
    /// </summary>
    /// <returns>
    /// Returns true if the event ID exists, false otherwise.
    /// </returns>
    public bool Exists()
    {
        return Id != null;
    }


    // STATIC METHODS

    /// <summary>
    /// Creates a new unique event ID that is not already in use by the user.
    /// </summary>
    /// <returns>
    /// A new unique event ID string.
    /// </returns>
    private static string BuildNewId()
    {
        string id = null;
        do
        {
            id = new string(CHARS.Select(c => CHARS[SecureRandom.RandomInt(CHARS.Length)])
                                 .Take(ID_LENGTH)
                                 .ToArray());
        }
        while (TAKEN.Contains(id));

        return id;
    }

    // OVERRIDES


    public int CompareTo(EventId other)
    {
        return string.CompareOrdinal(Id, other.Id);
    }
    
    public override string ToString()
    {
        return Id;
    }

    protected bool Equals(EventId other)
    {
        return string.Equals(Id, other.Id);
    }
    public override bool Equals(object obj)
    {
        if (ReferenceEquals(null, obj)) return false;
        if (ReferenceEquals(this, obj)) return true;
        if (obj.GetType() != this.GetType()) return false;
        return Equals((EventId) obj);
    }
    public override int GetHashCode()
    {
        return (Id != null ? Id.GetHashCode() : 0);
    }
}
